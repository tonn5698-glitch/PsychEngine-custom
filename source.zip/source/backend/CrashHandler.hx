package backend;

import openfl.events.UncaughtErrorEvent;
import openfl.events.ErrorEvent;
import openfl.errors.Error;
import flixel.addons.transition.FlxTransitionableState;
import backend.MusicBeatState;
#if sys
import sys.FileSystem;
import sys.io.File;
#end

using StringTools;
using flixel.util.FlxArrayUtil;

/**
 * Crash Handler — bắt lỗi Haxe/OpenFL, hiện CrashHandlerState thay vì đóng app.
 * Lưu crash log vào <storage>/crash/.
 * Có recursion protection: crash lần 2 → không switch tiếp.
 * KHÔNG bắt native crash (segfault, JNI, GPU driver, OOM kill).
 */
class CrashHandler
{
	// Recursion protection
	public static var crashHandlerActive:Bool = false;
	// Deferred crash: không switch state ngay trong error callback
	static var pendingCrash:Bool = false;
	static var pendingMsg:String = '';
	static var pendingStack:String = '';
	// Poll flag — kiểm tra mỗi frame
	public static var checkPendingCrash:Bool = false;

	public static function init():Void
	{
		openfl.Lib.current.loaderInfo.uncaughtErrorEvents.addEventListener(UncaughtErrorEvent.UNCAUGHT_ERROR, onUncaughtError);
		// Poll mỗi frame độc lập với state hiện tại: nếu state hỏng (lỗi trong create/update) thì
		// MusicBeatState.update không chạy nữa, nên không thể chờ nó xử lý crash.
		openfl.Lib.current.addEventListener(openfl.events.Event.ENTER_FRAME, function(_) processPendingCrash());
		#if cpp
		untyped __global__.__hxcpp_set_critical_error_handler(onError);
		#elseif hl
		hl.Api.setErrorHandler(onError);
		#end
	}

	/**
	 * Gọi mỗi frame (ENTER_FRAME) để chuyển sang CrashHandlerState an toàn.
	 * Không bao giờ thoát app: nếu không chuyển được thì chỉ log.
	 */
	public static function processPendingCrash():Void
	{
		if (!pendingCrash) return;
		pendingCrash = false;
		checkPendingCrash = false;

		var crashState:states.CrashHandlerState = null;
		try
		{
			crashState = new states.CrashHandlerState(pendingMsg, pendingStack);
		}
		catch (e:Dynamic)
		{
			trace('[CrashHandler] Failed to create CrashHandlerState: ' + e);
			return;
		}

		try { FlxG.sound.music.stop(); } catch (e:Dynamic) {}
		FlxTransitionableState.skipNextTransIn = true;
		FlxTransitionableState.skipNextTransOut = true;

		try
		{
			// State cũ có thể đã hỏng giữa chừng (vd: lỗi trong PlayState.create) nên:
			// - tự destroy trong try/catch (flixel sẽ không phải destroy lại),
			// - thay bằng state rỗng (state đã destroy có exists=false → FlxGame.update bỏ qua việc đổi state),
			// - đặt thẳng state tiếp theo, bỏ qua transition của MusicBeatState.switchState.
			@:privateAccess
			{
				var game = FlxG.game;
				try { if (game._state != null) game._state.destroy(); } catch (e:Dynamic) { trace('[CrashHandler] Old state destroy failed: ' + e); }
				game._state = new flixel.FlxState();
				FlxG.switchState(crashState);
			}
		}
		catch (e:Dynamic)
		{
			trace('[CrashHandler] Direct switch failed: ' + e);
			try { FlxG.switchState(crashState); } catch (e2:Dynamic) { trace('[CrashHandler] FlxG.switchState failed: ' + e2); }
		}
	}

	private static function onUncaughtError(e:UncaughtErrorEvent):Void
	{
		// LUÔN chặn lỗi (kể cả lỗi lặp lại mỗi frame của state hỏng) — không chặn thì runtime sẽ kill app
		e.preventDefault();
		e.stopPropagation();
		e.stopImmediatePropagation();

		// Recursion protection: các lỗi sau lỗi đầu tiên chỉ bị bỏ qua, không xử lý lại
		if (crashHandlerActive)
		{
			trace('[CrashHandler] Repeated error ignored');
			return;
		}
		crashHandlerActive = true;

		// Capture error message
		var m:String = 'Unknown error';
		try {
			m = e.error;
			if (Std.isOfType(e.error, Error))
			{
				var err = cast(e.error, Error);
				m = '${err.message}';
			}
			else if (Std.isOfType(e.error, ErrorEvent))
			{
				var err = cast(e.error, ErrorEvent);
				m = '${err.text}';
			}
		} catch (e:Dynamic) {
			m = 'Error capturing message: ' + e;
		}

		// Capture stack trace
		var stackLabel:String = '';
		try {
			stackLabel = captureStack();
		} catch (e:Dynamic) {
			stackLabel = 'Stack trace unavailable: ' + e;
		}

		// Save crash log + copy the crash into the active Haxe runtime log.
		saveCrashLog(m, stackLabel);
		HaxeLog.error(m, 'CrashHandler');
		if (stackLabel.length > 0) HaxeLog.error(stackLabel, 'StackTrace');

		// Defer state switch — KHÔNG switch ngay trong error callback
		pendingMsg = m;
		pendingStack = stackLabel;
		pendingCrash = true;
		checkPendingCrash = true;

		trace('[CrashHandler] Crash captured: ' + m);
	}

	#if (cpp || hl)
	private static function onError(message:Dynamic):Void
	{
		if (crashHandlerActive) return;
		crashHandlerActive = true;

		var msg:String = 'Critical error';
		var stackStr:String = '';
		try {
			if (message != null) msg = Std.string(message);
			stackStr = haxe.CallStack.toString(haxe.CallStack.exceptionStack(true));
		} catch (e:Dynamic) {}

		saveCrashLog(msg, stackStr);
		HaxeLog.error(msg, 'CriticalError');
		if (stackStr.length > 0) HaxeLog.error(stackStr, 'StackTrace');

		pendingMsg = msg;
		pendingStack = stackStr;
		pendingCrash = true;
		checkPendingCrash = true;
	}
	#end

	static function captureStack():String
	{
		var stack = haxe.CallStack.exceptionStack(true);
		var lines:Array<String> = [];
		for (e in stack)
		{
			switch (e)
			{
				case CFunction:
					lines.push('Non-Haxe (C) Function');
				case Module(c):
					lines.push('Module ${c}');
				case FilePos(parent, file, line, col):
					switch (parent)
					{
						case Method(cla, func):
							lines.push('${file.replace('.hx', '')}.$func() [line $line]');
						case _:
							lines.push('${file.replace('.hx', '')} [line $line]');
					}
				case LocalFunction(v):
					lines.push('Local Function ${v}');
				case Method(cl, m):
					lines.push('${cl} - ${m}');
			}
		}
		return lines.join('\n');
	}

	/** Nội dung đầy đủ của báo cáo crash (dùng cho file log và nút Copy). */
	public static function buildReport(message:String, stack:String):String
	{
		return [
			'---',
			'PSYCH ENGINE CRASH REPORT',
			'',
			'Date: ' + Date.now().toString(),
			'Platform: ' + #if android 'Android' #elseif desktop 'Desktop' #else 'Unknown' #end,
			'Engine version: ' + states.MainMenuState.psychEngineVersion,
			'',
			'Exception:',
			message,
			'',
			'Stack trace:',
			stack,
			'---'
		].join('\n');
	}

	static function saveCrashLog(message:String, stack:String):Void
	{
		try {
			#if sys
			var folder:String = #if android
				mobile.backend.StorageUtil.getExternalStorageDirectory() + #else Sys.getCwd() + #end
				'crash/';
			if (!FileSystem.exists(folder))
				FileSystem.createDirectory(folder);

			// Timestamp an toàn cho Android (không dùng ':')
			var now = Date.now();
			var ts:String = now.getFullYear() + '-' +
				StringTools.lpad(Std.string(now.getMonth() + 1), '0', 2) + '-' +
				StringTools.lpad(Std.string(now.getDate()), '0', 2) + '_' +
				StringTools.lpad(Std.string(now.getHours()), '0', 2) + '-' +
				StringTools.lpad(Std.string(now.getMinutes()), '0', 2) + '-' +
				StringTools.lpad(Std.string(now.getSeconds()), '0', 2);

			var content:String = buildReport(message, stack);

			File.saveContent(folder + 'crash_' + ts + '.txt', content);
			trace('[CrashHandler] Crash log saved to ' + folder);
			#end
		} catch (e:Dynamic) {
			trace('[CrashHandler] Failed to save crash log: ' + e);
		}
	}
}
